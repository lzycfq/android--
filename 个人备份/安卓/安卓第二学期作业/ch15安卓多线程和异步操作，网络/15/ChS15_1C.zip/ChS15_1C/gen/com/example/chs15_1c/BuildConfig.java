/** Automatically generated file. DO NOT MODIFY */
package com.example.chs15_1c;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}