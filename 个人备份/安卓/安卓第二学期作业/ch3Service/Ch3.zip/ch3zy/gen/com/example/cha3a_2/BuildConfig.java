/** Automatically generated file. DO NOT MODIFY */
package com.example.cha3a_2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}