/** Automatically generated file. DO NOT MODIFY */
package com.example.chs26_1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}