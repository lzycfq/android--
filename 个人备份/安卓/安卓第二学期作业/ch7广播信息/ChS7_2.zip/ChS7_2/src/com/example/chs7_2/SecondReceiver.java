package com.example.chs7_2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class SecondReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		//��ȡBundle��Ϣ
		Bundle bundle=getResultExtras(true);
		String first=bundle.getString("first");
		Toast.makeText(context, String.format("�ӵ�һ��Receiver���յ���Ϣ��:%s", first), Toast.LENGTH_LONG).show();
	}
}
