package com.example.chs13_1;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener, Runnable {
	Button btnStart;
	TextView textMsg;
	Handler handler;
	boolean isRunning;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		btnStart = (Button) findViewById(R.id.btnStart);
		textMsg = (TextView) findViewById(R.id.textMsg);
		btnStart.setOnClickListener(this);

		handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				switch (msg.what) {
				case 4:
					textMsg.setText("��ȥ�� " + msg.obj + " ��");
				}
				super.handleMessage(msg);
			}
		};
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void run() {
		int timer = 0;
		while (isRunning) {
			timer++;
			Message m = new Message();
			m.obj = timer;
			m.what = 4;
			handler.sendMessage(m);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onClick(View v) {
		if (isRunning) {
			isRunning = false;
			btnStart.setText("��ʼ");
		} else {
			isRunning = true;
			Thread t = new Thread(this);
			t.start();
			btnStart.setText("ֹͣ");
		}

	}
}
