package songTab;

import Song.songActivty.R;
import android.app.Activity;
import android.os.Bundle;

public class TabTwo extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tabhost_one);
		
	}
}
