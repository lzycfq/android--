package com.example.chs19_1;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends Activity implements OnClickListener {
	EditText editUrl;
	WebView wvBrowser;
	Button btnGo;

	//Web��ͼ  
    private class HelloWebViewClient extends WebViewClient {  
        @Override 
        public boolean shouldOverrideUrlLoading(WebView view, String url) {  
            view.loadUrl(url);  
            return true;  
        }  
    }  
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        editUrl=(EditText)findViewById(R.id.editUrl);
        wvBrowser=(WebView)findViewById(R.id.wvBrowser);
        //����ʹ���Զ����View��ͼ
        wvBrowser.setWebViewClient(new HelloWebViewClient());
        btnGo=(Button)findViewById(R.id.btnGo);
        btnGo.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {      
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {        
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
    	if(keyCode==KeyEvent.KEYCODE_SEARCH){
    		go();
    	}
    	if ((keyCode == KeyEvent.KEYCODE_BACK) && wvBrowser.canGoBack()) {  
    		wvBrowser.goBack(); //goBack()��ʾ����WebView����һҳ��  
            return true;  
        }  
    	return super.onKeyDown(keyCode, event);
    }
    
    protected void go() {
    	String url=editUrl.getText().toString();
    	wvBrowser.loadUrl(url);
	}

	@Override
	public void onClick(View v) {
		go();		
	}	
	
}
