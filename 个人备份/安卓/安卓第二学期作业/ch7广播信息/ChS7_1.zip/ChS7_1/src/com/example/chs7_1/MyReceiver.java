package com.example.chs7_1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		String msg = String.format("�㲥��ַ %s �յ�����Ϣ��%s",intent.getAction(), intent.getStringExtra("msg"));
		Toast.makeText(	context, msg, Toast.LENGTH_LONG).show();
	}
}
