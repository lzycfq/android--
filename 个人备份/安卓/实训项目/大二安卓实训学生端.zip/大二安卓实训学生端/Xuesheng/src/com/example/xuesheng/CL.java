package com.example.xuesheng;

public  class CL {
	static String sid=null; 
	static String sname=null; 
	public static void setSid(String s){
		sid=s;
	}
	public static String getSid(){
		return sid;
	}
	public static void setSname(String s){
		sname=s;
	}
	public static String getSname(){
		return sname;
	}
}
