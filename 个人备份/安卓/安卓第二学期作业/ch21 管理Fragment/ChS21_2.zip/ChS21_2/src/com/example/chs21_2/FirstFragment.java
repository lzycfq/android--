package com.example.chs21_2;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.TextView;

public class FirstFragment extends Fragment {
	
	int i=0;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		i++;
		View view=inflater.inflate(R.layout.fragment_first, container,false);
		TextView textCount=(TextView)view.findViewById(R.id.textCount);
		textCount.setText(String.format("%d", i));
		return view;
	}

}
