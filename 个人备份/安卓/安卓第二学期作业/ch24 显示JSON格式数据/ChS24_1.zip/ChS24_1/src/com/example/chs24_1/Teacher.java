package com.example.chs24_1;

public class Teacher {
	String name;
	String subject;

	public String getName() {return name;}

	public void setName(String name) {this.name = name;}

	public String getSubject() {return subject;	}

	public void setSubject(String subject) {this.subject = subject;	}

	public Teacher() {super();};

	public Teacher(String name, String subject) {
		super();
		this.name = name;
		this.subject = subject;
	}
}
