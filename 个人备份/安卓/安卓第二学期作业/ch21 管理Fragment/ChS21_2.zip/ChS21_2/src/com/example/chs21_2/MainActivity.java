package com.example.chs21_2;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener {
	Button btnHome;
	Button btnMine;
	FragmentManager fragmentManager;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		btnHome = (Button) findViewById(R.id.btnHome);
		btnMine = (Button) findViewById(R.id.btnMine);
		btnHome.setOnClickListener(this);
		btnMine.setOnClickListener(this);

		// ����Fragment������
		fragmentManager = getFragmentManager();
		// ����Fragment
		addFragment("home");

	}

	protected void addFragment(String tag) {
		FragmentTransaction trans = fragmentManager.beginTransaction();
		// ��ȡfragment
		Fragment fragment = fragmentManager.findFragmentByTag(tag);
		boolean canAdd = false;
		//�ж��Ƿ��м�¼
		if (fragment == null)
			canAdd = true;
		else if (!fragment.isAdded()) {
			canAdd = true;
		}
		if (canAdd && tag.equals("home"))
			trans.add(R.id.fragmentShow, new FirstFragment(), tag);
		else if (canAdd && tag.equals("mine")) {
			trans.add(R.id.fragmentShow, new SecondFragment(), tag);
		}

		trans.commit();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	protected void changeFragment(String tag) {
		FragmentTransaction trans = fragmentManager.beginTransaction();
		Fragment f = fragmentManager.findFragmentByTag(tag);
		if (f != null && f.isAdded()) {
			// �滻fragment��������
			trans.detach(f);
			trans.attach(f);
			trans.commit();
		} else
			addFragment(tag);

	}

	@Override
	public void onClick(View v) {
		// ���ݰ�ť��id�滻��ͬ��Fragment
		switch (v.getId()) {
		case R.id.btnHome:
			changeFragment("home");
			break;
		case R.id.btnMine:
			changeFragment("mine");
			break;
		}

	}
}
