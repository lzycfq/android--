package AppFinal;

public class AppFinal {
	public static  final  String item_one="ONE";
	public static  final  String item_two="TWO";
	public static  final  String item_three="THREE";
	public static  final  String list_item_one="list_item_one";
	public static  final  String list_item_two="list_item_two";
	public static  final  String DOWN_MUSIC_WENJIANJIA="DOWN_MUSIC_WENJIANJIA";
}
