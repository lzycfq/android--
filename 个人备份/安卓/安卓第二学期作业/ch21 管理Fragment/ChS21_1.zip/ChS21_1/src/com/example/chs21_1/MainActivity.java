package com.example.chs21_1;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MainActivity extends Activity implements OnClickListener {
	Button btnHome;
	Button btnMine;
	FragmentManager fragmentManager;
	Fragment fragFirst;
	Fragment fragSecond;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        btnHome=(Button)findViewById(R.id.btnHome);
        btnMine=(Button)findViewById(R.id.btnMine);
        btnHome.setOnClickListener(this);
        btnMine.setOnClickListener(this);
        //����fragment
        fragFirst=new FirstFragment();
        fragSecond=new SecondFragment();       
        //����Fragment������
        fragmentManager=getFragmentManager();
        //����Fragment
        setFragment(fragFirst);
    }
    
    protected void setFragment(Fragment frag){
    	FragmentTransaction trans=fragmentManager.beginTransaction();
    	//�滻fragment��������
    	trans.replace(R.id.fragmentShow, frag);    	
    	trans.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {        
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
       
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

	@Override
	public void onClick(View v) {
		//���ݰ�ť��id�滻��ͬ��Fragment
		switch(v.getId()){
		case R.id.btnHome:
			setFragment(fragFirst);
			break;
		case R.id.btnMine:
			setFragment(fragSecond);
			break;
		}

	}
}
