/** Automatically generated file. DO NOT MODIFY */
package Song.songActivty;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}