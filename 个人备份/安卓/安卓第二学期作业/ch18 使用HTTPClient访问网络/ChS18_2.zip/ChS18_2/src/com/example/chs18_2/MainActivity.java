package com.example.chs18_2;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
	EditText editSno;
	EditText editPassword;
	Button btnLogin;

	class NetworkTask extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			String urlString = "http://10.0.2.2:8080/LoginCheck";
			String result = null;
			//����HttpPost������post��ʽ����
			HttpPost request = new HttpPost(urlString);
			//�����ֵ�Եļ���
			List<NameValuePair> postparams = new ArrayList<NameValuePair>();
			//�Լ�ֵ�Ե���ʽ�����������
			postparams.add(new BasicNameValuePair("sno", params[0]));
			postparams.add(new BasicNameValuePair("password", params[1]));
			try {
				//��ȫ��������ʵ��ĸ�ʽ���б�������
				request.setEntity(new UrlEncodedFormEntity(postparams, "UTF-8"));
				//����HttpClient
				HttpClient client = new DefaultHttpClient();
				//ִ�����󣬲��õ���Ӧ�Ķ���
				HttpResponse response = client.execute(request);
				if (response.getStatusLine().getStatusCode() == 200) {
					//����Ӧ��������Ϊʵ������ת��Ϊ�ַ���
					result=EntityUtils.toString(response.getEntity());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return result;
		}

		@Override
		protected void onPostExecute(String result) {
			if (result!=null&&result.trim().equals("pass"))
				Toast.makeText(getApplicationContext(), "��¼�ɹ�",
						Toast.LENGTH_LONG).show();
			else
				Toast.makeText(getApplicationContext(), "��¼ʧ��",
						Toast.LENGTH_LONG).show();
			super.onPostExecute(result);
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		editSno = (EditText) findViewById(R.id.editSno);
		editPassword = (EditText) findViewById(R.id.editPassword);
		btnLogin = (Button) findViewById(R.id.btnLogin);
		btnLogin.setOnClickListener(this);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {		
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {		
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {
		String password = editPassword.getText().toString();
		String sno = editSno.getText().toString();
		new NetworkTask().execute(sno, password);
	}
}
