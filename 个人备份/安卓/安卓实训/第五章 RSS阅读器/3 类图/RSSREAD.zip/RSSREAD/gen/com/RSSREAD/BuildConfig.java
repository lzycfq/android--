/** Automatically generated file. DO NOT MODIFY */
package com.RSSREAD;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}