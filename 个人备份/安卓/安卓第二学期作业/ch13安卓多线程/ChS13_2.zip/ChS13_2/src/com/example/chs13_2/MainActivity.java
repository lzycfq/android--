package com.example.chs13_2;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity implements OnClickListener {

	Button btnStart;
	TextView textMsg;
	boolean isRunning;
	int timer = 0;

	class TimeTask extends AsyncTask<Void, Integer, Void> {
		@Override
		protected Void doInBackground(Void... params) {
			timer = 0;
			while (isRunning) {
				timer++;
				//���͸��½���
				publishProgress(timer);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {					
					e.printStackTrace();
				}
			}
			return null;
		}		
		@Override
		protected void onProgressUpdate(Integer... values) {
			textMsg.setText("��ȥ�� " +values[0]+ " ��");
			super.onProgressUpdate(values);
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		btnStart = (Button) findViewById(R.id.btnStart);
		textMsg = (TextView) findViewById(R.id.textMsg);
		btnStart.setOnClickListener(this);
		isRunning = false;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onClick(View v) {
		if (isRunning) {
			isRunning = false;
			btnStart.setText("��ʼ");
		} else {
			isRunning = true;
			//�����첽ִ�ж��󣬲�����
			new TimeTask().execute();
			btnStart.setText("ֹͣ");
		}
	}
}
